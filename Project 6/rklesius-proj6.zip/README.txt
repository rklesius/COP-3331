These solutions were written and built in Microsoft Visual Studio 2017.  

TempDriver.cpp depends on FeetInches.h in order to run, so they must be in the same directory. 

There are no further compiling instructions beyond opening the file in the IDE, going to file -> new -> project from existing code
and then selecting visual c++, clicking next, and searching for the file within your computer.  From there, go to build -> build solution
and then hit ctrl + F5 on your keyboard to run the program.  

Thank you for your time,
Rachel Klesius